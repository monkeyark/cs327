#include "cf.h"

float c2f(float c)
{
  return (c * (9.0 / 5.0)) + 32;
}
