#ifndef CF_H
# define CF_H

float c2f(float c);
float f2c(float f);

#endif
