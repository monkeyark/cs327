#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"
#include "cf.h"

float f2c(float f)
{
  return (f - 32) * (5.0 / 9.0);
}
